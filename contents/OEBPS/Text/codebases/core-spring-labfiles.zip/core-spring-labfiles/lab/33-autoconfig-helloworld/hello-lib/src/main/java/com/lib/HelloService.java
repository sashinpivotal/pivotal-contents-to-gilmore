package com.lib;

public interface HelloService {
  void greet();
}
